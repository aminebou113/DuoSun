$(document).ready(function(){
    var carousel = $('.carousel');
    carousel.slick({
        dots: false,
        infinite: true,
        speed: 500,
        swipe: false,
        arrows: false,
    });

    $('.select-carousel .container-img img').on('click', function (){
        carousel.slick("slickGoTo",$(this).attr('data-number'));
        $('.select-carousel .container-img .selected').removeClass('selected');
        $(this).addClass('selected');
    });

    // Select image in terms of value selected in select
    /*$('.select-container select').on('change', (e) => {
        $('.select-carousel .container-img img[value-from-select*="'+$(e.currentTarget)[0].value+'"]').trigger('click');
    });
    */
    $('.select-container input[type=radio]').on('change', (e) => {
        //$('.select-carousel .container-img img[value-from-select*="'+$(e.currentTarget)[0].value+'"]').trigger('click');
        $('.select-carousel .container-img img[value-from-select="'+$(e.currentTarget)[0].value+'"]').trigger('click');

    });

});