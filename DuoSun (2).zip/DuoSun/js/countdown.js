
    var countdown, init_countdown, set_countdown;

    countdown = new FlipClock($('.countdown'), {
        clockFace: 'HourlyCounter',
        language: 'en',
        autoStart: true,
        countdown: true,
        showSeconds: true,
        callbacks: {
            start: function() {
                //return console.log('The clock has started!');
            },
            stop: function() {
                //return console.log('The clock has stopped!');
            },
            interval: function() {
                //return console.log(this.factory.getTime().time);
            }
        }
    });

    set_countdown = function(seconds, start) {
        var elapsed, end, left_secs, now;

        if(countdown.running) return;

        now = new Date;
        start = new Date(start);
        end = start.getTime() + seconds * 1000;
        left_secs = Math.round((end - now.getTime()) / 1000);
        if (left_secs < 0) {
            document.getElementById('countdown').style.display = 'none';
            return false;
        }else{
            countdown.setTime(left_secs);
            return countdown.start();
        }
    };


    //var currentDate = new Date();
    //set_countdown((59-currentDate.getMinutes())+((59-currentDate.getSeconds())*100/60/100), currentDate);