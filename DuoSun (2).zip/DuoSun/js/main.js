$(document).ready(function(){
   $('.responsive-menu-button').on('click', () => {
      $('.primary-nav').toggleClass('active');
   });
});